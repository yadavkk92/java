package com.assignment.recruitment.offer;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Offer {

	
	  private String jobTitle; 
	//  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "YYYY-MM-DD")
	  private String startDate; 
	  private int numberOfApplications;
	  
	public Offer() {
	}
	public Offer(String jobTitle, String startDate, int numberOfApplications) {
		super();
		this.jobTitle = jobTitle;
		this.startDate = startDate;
		this.numberOfApplications = numberOfApplications;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public int getNumberOfApplications() {
		return numberOfApplications;
	}
	public void setNumberOfApplications(int numberOfApplications) {
		this.numberOfApplications = numberOfApplications;
	}
	 

}
