package com.assignment.recruitment.offer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.assignment.recruitment.database.DatabaseClass;

@Service
public class OfferService {
	
	private Map<Integer, Offer> offers = DatabaseClass.getOffers();
	
			
    public List<Offer> getAllOffers(){
		ArrayList<Offer> alloffers = new ArrayList<>(offers.values());
		return alloffers;
			
    }
	
	 public Offer getOffer(String id) {
		return null;
       
	 }
	  public void addOffer(Offer offer) { 
		  }
	  }
	 

